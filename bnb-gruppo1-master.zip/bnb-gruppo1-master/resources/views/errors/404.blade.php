@extends('layouts.app')

@section('content')
<div class="container" style="position: relative; top: 120px;">
  <div class="alert alert-danger error_message text-center" role="alert">
    <h3 class="alert-heading">404 Not found!</h3>
  </div>
</div>
@endsection
@section('title','404 Not Found')
